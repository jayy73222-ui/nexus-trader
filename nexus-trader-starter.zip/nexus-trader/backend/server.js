const express = require('express');
const path = require('path');
const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// Deliberately fail closed: this starter build never enables live execution.
const tradingMode = 'demo';
const liveTradingEnabled = false;

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, app: 'NEXUS TRADER', tradingMode, liveTradingEnabled });
});

app.get('/api/markets', (_req, res) => {
  res.json([
    { id: 'deriv', name: 'Deriv', status: 'planned' },
    { id: 'mt5', name: 'MetaTrader 5', status: 'later_phase' },
    { id: 'binance', name: 'Binance', status: 'planned' },
    { id: 'tradingview', name: 'TradingView', status: 'planned' },
    { id: 'dbtraders', name: 'DB Traders', status: 'pending_api_confirmation' }
  ]);
});

app.post('/api/orders', (_req, res) => {
  return res.status(403).json({
    ok: false,
    error: 'Order execution is not implemented in this starter build.',
    tradingMode,
    liveTradingEnabled
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`NEXUS TRADER listening on port ${PORT}`);
});
