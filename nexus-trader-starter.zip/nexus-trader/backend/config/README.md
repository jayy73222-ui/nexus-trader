Server configuration belongs here. Keep secrets in Railway environment variables, never in Git.
