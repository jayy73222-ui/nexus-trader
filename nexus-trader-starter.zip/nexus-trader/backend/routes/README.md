API route modules can be added here as the application grows.
