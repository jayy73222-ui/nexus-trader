const test = require('node:test');
const assert = require('node:assert/strict');

test('starter safety policy is demo-only and live trading remains disabled', () => {
  const tradingMode = 'demo';
  const liveTradingEnabled = false;
  assert.equal(tradingMode, 'demo');
  assert.equal(liveTradingEnabled, false);
});
