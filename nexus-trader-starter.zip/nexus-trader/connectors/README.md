# Provider connectors

Each connector is intentionally a placeholder. Before implementing one, confirm the provider's official API, authentication method, permitted use, demo/test environment, rate limits, and order semantics.

Never put credentials in source code. Use server-side environment variables and least-privilege API permissions. Start with read-only market data, then demo execution only after tests.
