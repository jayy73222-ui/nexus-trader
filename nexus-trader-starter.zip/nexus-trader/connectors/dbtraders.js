// TODO: Confirm DB Traders API documentation and authorized integration method.
// Website: https://dbtradars.com
module.exports = { provider: 'DB Traders', implemented: false };
