// TODO: Define a verified TradingView alert/webhook ingestion flow.
// TradingView chart display is not the same as a broker execution API.
module.exports = { provider: 'TradingView', implemented: false };
