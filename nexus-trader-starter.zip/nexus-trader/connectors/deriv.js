// TODO: Implement Deriv official API authentication and demo-only market data.
// Do not store app tokens or account tokens in this file.
module.exports = { provider: 'Deriv', implemented: false };
