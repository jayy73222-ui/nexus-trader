// TODO: Implement Binance public market data, then testnet only.
// Never use production trading credentials in development.
module.exports = { provider: 'Binance', implemented: false };
