# NEXUS TRADER

Starter scaffold for a multi-market trading dashboard.

## Current safety state
- Trading mode: demo-only.
- Live execution: hard-locked in the starter backend.
- No exchange credentials are included.
- Connectors are integration placeholders until each provider's official API/authentication flow is implemented and tested.

## Stack
- Frontend: HTML, CSS, vanilla JavaScript
- Backend: Node.js + Express
- Hosting target: Railway

## Run locally
1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env` and adjust only non-secret settings.
4. Run `npm start`.
5. Open http://localhost:3000

## Repository structure
- `frontend/`: dashboard UI
- `backend/`: API server and safety gate
- `connectors/`: provider integration placeholders
- `tests/`: basic safety checks

## Important
Do not commit `.env`, API tokens, passwords, OAuth secrets, or account identifiers.
Never enable live trading by changing a frontend setting. A separately reviewed backend implementation, risk controls, provider permissions, and demo verification are required first.
