# MetaTrader 5 connector (later phase)

MT5 integration is intentionally deferred as requested. Choose and review the official/authorized bridge architecture before adding credentials or execution functionality.
